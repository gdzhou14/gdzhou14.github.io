Title: Article with markdown containing footnotes
Date: 2012-10-31
Modified: 2012-11-01
Summary: Summary with **inline** markup *should* be supported.
Multiline: Line Metadata should be handle properly.
    See syntax of Meta-Data extension of Python Markdown package:
    If a line is indented by 4 or more spaces,
    that line is assumed to be an additional line of the value
    for the previous keyword.
    A keyword may have as many lines as desired.

This is some content[^1] with some footnotes[^footnote]

[^1]: Numbered footnote
[^footnote]: Named footnote
