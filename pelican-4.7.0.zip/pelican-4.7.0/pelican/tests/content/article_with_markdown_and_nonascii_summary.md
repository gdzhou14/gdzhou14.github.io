Title: マックOS X 10.8でパイソンとVirtualenvをインストールと設定
Slug: python-virtualenv-on-mac-osx-mountain-lion-10.8
Date: 2012-12-20
Modified: 2012-12-22
Tags: パイソン, マック
Category: 指導書
Summary: パイソンとVirtualenvをまっくでインストールする方法について明確に説明します。

Writing unicode is certainly fun.

パイソンとVirtualenvをまっくでインストールする方法について明確に説明します。

And let's mix languages.

первый пост

Now another.

İlk yazı çok özel değil.
