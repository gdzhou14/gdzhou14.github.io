One -, two --, three --- dashes!
################################

One: -; Two: --; Three: ---
