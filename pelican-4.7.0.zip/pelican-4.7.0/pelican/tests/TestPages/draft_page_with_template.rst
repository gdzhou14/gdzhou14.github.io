This is a test draft page with a custom template
#################################################

:status: draft
:template: custom

The quick brown fox .

This page is a draft

This page has a custom template to be called when rendered
