Title: Page with static links

My links:

[Link 0]({static}image0.jpg)

[Link 1]({attach}image1.jpg)
