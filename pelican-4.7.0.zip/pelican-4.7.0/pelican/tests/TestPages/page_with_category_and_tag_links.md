Title: Page with a bunch of links

My links:

[Link 1]({tag}マック)

[Link 2]({category}Yeah)
