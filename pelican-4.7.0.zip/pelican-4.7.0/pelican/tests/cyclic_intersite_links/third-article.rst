Third article
#############

:date: 2018-11-10
:summary: Here's the `first <{filename}/first-article.rst>`_,
    `second <{filename}/second-article.rst>`_ and a
    `nonexistent article <{filename}/nonexistent.rst>`_.
