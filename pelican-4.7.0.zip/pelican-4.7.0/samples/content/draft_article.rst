A draft article
###############

:date: 2011-05-08 15:58
:status: draft

This is a draft article, it should live under the /drafts/ folder and not be
listed anywhere else.
