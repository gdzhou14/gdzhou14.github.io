This is a super article !
#########################

:tags: foo, bar, foobar
:date: 2010-12-02 10:14
:modified: 2013-11-17 23:29
:category: yeah
:author: Alexis Métaireau
:summary:
    Multi-line metadata should be supported
    as well as **inline markup**.

Some content here !

This is a simple title
======================

And here comes the cool stuff_.

.. image:: |static|/pictures/Sushi.jpg
   :height: 450 px
   :width: 600 px
   :alt: alternate text

.. image:: |static|/pictures/Sushi_Macro.jpg
   :height: 450 px
   :width: 600 px
   :alt: alternate text

::

   >>> from ipdb import set_trace
   >>> set_trace()

→ And now try with some utf8 hell: ééé

.. _stuff: http://books.couchdb.org/relax/design-documents/views
