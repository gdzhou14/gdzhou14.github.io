This is a test page
###################

:category: test

Just an image.

.. image:: {static}/pictures/Fat_Cat.jpg
   :height: 450 px
   :width: 600 px
   :alt: alternate text

.. image:: |filename|/images/Fat_Cat.jpg
   :height: 450 px
   :width: 600 px
   :alt: wrong path since 'images' folder does not exist
